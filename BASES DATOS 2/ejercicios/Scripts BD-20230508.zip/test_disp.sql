CREATE DATABASE test_disp;
USE test_disp;
CREATE TABLE prova (codi INT); 
CREATE TABLE suma (suma INT); 
CREATE TABLE suma_text (suma VARCHAR(200)); 
