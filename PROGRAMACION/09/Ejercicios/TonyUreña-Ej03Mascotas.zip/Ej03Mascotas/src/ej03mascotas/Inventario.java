package ej03mascotas;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class Inventario {

    private ArrayList<Mascota> listaAnimales = new ArrayList();
    private Iterator it = listaAnimales.iterator();
    
    public void muestraListaAnimales() {
        Mascota mascota;
        while (it.hasNext()) {
            mascota = (Mascota) it.next();
            System.out.println("--------------------------");
            System.out.println("Nombre: " + mascota.getNombre() + " | Tipo: " + mascota.getTipo());
            System.out.println("--------------------------");
        }
    }

    public void muestraDatosAnimal() {
        muestraDatos(buscaMascota(listaAnimales));
    }

    public void muestraDatosTodosAnimales() {
        Mascota mascota;
        while (it.hasNext()) {
            mascota = (Mascota) it.next();
            muestraDatos(mascota);
        }
    }

    public void anadirAnimalInventario() {
        Scanner reader = new Scanner(System.in);
        String tipo, nombre;
        int edad, fechaNacimiento;

        System.out.println("Introduce el tipo de animal (perro, gato, loro o canario): ");
        tipo = reader.nextLine();
        if (tipo.equals("Perro")) {
            String raza;
            boolean pulgas = false;
            Perro guau;

            System.out.println("Nombre: ");
            nombre = reader.nextLine();
            System.out.println("Edad: ");
            edad = reader.nextInt();
            System.out.println("Fecha de nacimiento: ");
            fechaNacimiento = reader.nextInt();
            reader.nextLine();

            System.out.println("Raza: ");
            raza = reader.nextLine();
            System.out.println("Tiene Pulgas (SI o NO): ");
            String opcionPulgas = reader.nextLine();
            if (opcionPulgas.equals("SI")) {
                pulgas = true;
            } else if (opcionPulgas.equals("NO")) {
                pulgas = false;
            }

            guau = new Perro(nombre, edad, fechaNacimiento, raza, pulgas);
            listaAnimales.add(guau);
        }
        if (tipo.equals("Gato")) {
            String color;
            boolean peloLargo = false;
            Gato miau;

            System.out.println("Nombre: ");
            nombre = reader.nextLine();
            System.out.println("Edad: ");
            edad = reader.nextInt();
            System.out.println("Fecha de nacimiento: ");
            fechaNacimiento = reader.nextInt();
            reader.nextLine();

            System.out.println("Color: ");
            color = reader.nextLine();
            System.out.println("Tiene pelo largo (SI o NO): ");
            String opcionPelo = reader.nextLine();
            if (opcionPelo.equals("SI")) {
                peloLargo = true;
            } else if (opcionPelo.equals("NO")) {
                peloLargo = false;
            }

            miau = new Gato(nombre, edad, fechaNacimiento, color, peloLargo);
            listaAnimales.add(miau);
        }
        if (tipo.equals("Loro")) {
            String origen;
            Loro hola;

            System.out.println("Nombre: ");
            nombre = reader.nextLine();
            System.out.println("Edad: ");
            edad = reader.nextInt();
            System.out.println("Fecha de nacimiento: ");
            fechaNacimiento = reader.nextInt();
            reader.nextLine();

            System.out.println("Origen: ");
            origen = reader.nextLine();

            hola = new Loro(nombre, edad, fechaNacimiento, origen);
            listaAnimales.add(hola);
        }
        if (tipo.equals("Canario")) {
            String color;
            Canario pio;

            System.out.println("Nombre: ");
            nombre = reader.nextLine();
            System.out.println("Edad: ");
            edad = reader.nextInt();
            System.out.println("Fecha de nacimiento: ");
            fechaNacimiento = reader.nextInt();
            reader.nextLine();

            System.out.println("Color:");
            color = reader.nextLine();

            pio = new Canario(nombre, edad, fechaNacimiento, color);

            listaAnimales.add(pio);
        }
    }

    public void retirarAnimalInventario() {
        listaAnimales.remove(buscaMascota(listaAnimales));
    }

    public void vaciaInventario() {
        listaAnimales.clear();
    }

    public void muestraDatos(Mascota mascota) {
        System.out.println("--------------------------");
        System.out.println("Nombre: " + mascota.getNombre() + " | Tipo: " + mascota.getTipo());
        System.out.println("Edad: " + mascota.getEdad() + " | Fecha Nac.: " + mascota.getFechaNacimiento());
        mascota.muestra();
        System.out.print("Habla: ");
        if (mascota.habla) {
            System.out.println("SI");
        } else {
            System.out.println("NO");
        }
        System.out.println("Vive: ");
        if (mascota.estado) {
            System.out.println("SI");
        } else {
            System.out.println("NO");
        }
        System.out.println("--------------------------");
    }

    public Mascota buscaMascota(ArrayList listaMascotas) {
        Scanner reader = new Scanner(System.in);
        String nombreMascota;
        Mascota mascota = null, mascotaBuscar;

        System.out.print("Introduce el nombre del animal a buscar:");
        nombreMascota = reader.nextLine();

        while (it.hasNext()) {
            mascotaBuscar = (Mascota) it.next();
            if (mascotaBuscar.getNombre().equals(nombreMascota)) {
                mascota = mascotaBuscar;
            }
        }
        return mascota;
    }

}
