package ej03mascotas;

import java.time.LocalDate;
import java.util.Date;

public class Menu {

    public static void main(String[] args) {
        
        Inventario.listaAnimales.add(new Perro("Princesa", 350, 271186, "Pit Bull", true));
        Inventario.listaAnimales.add(new Gato("Alimento", 3, 13022022, "Turquesa", true));
        Inventario.listaAnimales.add(new Loro("Periquito", 83, 10022013, "Republica dominicana"));
        Inventario.listaAnimales.add(new Canario("Santiago", 3, 21082013, "#FF2598"));
        
    }

}

