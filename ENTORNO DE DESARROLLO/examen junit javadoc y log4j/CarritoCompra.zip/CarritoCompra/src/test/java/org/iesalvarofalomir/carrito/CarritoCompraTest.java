/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package org.iesalvarofalomir.carrito;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class CarritoCompraTest {

    public CarritoCompraTest() {
    }

    @BeforeAll
    public static void setUpClass() throws Exception {
    }

    @AfterAll
    public static void tearDownClass() throws Exception {
    }

    @BeforeEach
    public void setUp() throws Exception {
    }

    @AfterEach
    public void tearDown() throws Exception {
    }

    /**
     * Test of getCantidadProductos method, of class CarritoCompra.
     */
    @Test
    public void testGetCantidadProductos() {
        System.out.println("getCantidadProductos");
        CarritoCompra carrito = new CarritoCompra();
        int esperado = 0;
        int resultado = carrito.getCantidadProductos();
        assertEquals(esperado, resultado);

    }

    /**
     * Test of vaciarCarrito method, of class CarritoCompra.
     */
    @Test
    public void testVaciarCarrito() {
        System.out.println("vaciarCarrito");
        CarritoCompra carrito = new CarritoCompra();
        int esperado = 0;
        int resultado = carrito.getCantidadProductos();
        carrito.vaciarCarrito();
        assertEquals(esperado, resultado);
    }

    /**
     * Test of agregaProducto method, of class CarritoCompra.
     */
    @Test
    public void testAgregaProducto() {
        System.out.println("agregaProducto");

        Producto producto = new Producto("a", 2);
        CarritoCompra carrito = new CarritoCompra();

        int esperadoProducto = carrito.getCantidadProductos() + 1;
        double esperadoPrecio = carrito.getPrecioTotal() + producto.getPrecio();
        carrito.agregaProducto(producto);

        int resultadoProducto = carrito.getCantidadProductos();
        assertEquals(esperadoProducto, resultadoProducto);

        double resultadoPrecio = carrito.getPrecioTotal();
        assertEquals(esperadoPrecio, resultadoPrecio);

    }

    /**
     * Test of borraProducto method, of class CarritoCompra.
     */
    @Test
    public void testBorraProducto() throws Exception {
        System.out.println("borraProducto");

        Producto producto = new Producto("a", 2);
        CarritoCompra carrito = new CarritoCompra();

        carrito.agregaProducto(producto);
        int esperadoProducto = carrito.getCantidadProductos() - 1;

        carrito.borraProducto(producto);

        int resultadoProducto = carrito.getCantidadProductos();
        assertEquals(esperadoProducto, resultadoProducto);

    }

    @Test
    public void testExcepcion() throws ProductNotFoundException {
        System.out.println("exception");

        CarritoCompra carrito = new CarritoCompra();
        Producto producto = new Producto("a", 2);
        
        assertThrows(ProductNotFoundException.class, () -> carrito.borraProducto(producto));
        
    }

}
