/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package org.iesalvarofalomir.carrito;

import java.util.stream.Stream;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import static org.junit.jupiter.params.provider.Arguments.arguments;
import org.junit.jupiter.params.provider.MethodSource;

/**
 *
 * @author xubaka
 */
public class ProductoTest {
    
    public ProductoTest() {
    }
    
    @ParameterizedTest
    @MethodSource("metodoTestConstructorProducto")
    public void testConstructor() {
        System.out.println("constructor");
        
        
    }

    
    /**
     * Test of equals method, of class Producto.
     */
    @ParameterizedTest
    @MethodSource("metodoTestEquals")
    public void testEquals(Producto a, Producto b, boolean resultadoEsperado) {
        System.out.println("equals");
        
        // comprueba iguales
        boolean expResult = true;
        boolean resultado = a.equals(b);
        
        assertEquals(resultadoEsperado, resultado);        
        
    }
    
    private static Stream<Arguments> metodoTestEquals() {
        
        Producto a = new Producto("a",2);
        Producto b = new Producto("b",2);
        
        return Stream.of(arguments(a,b,true));
        
    
    }
    private static Stream<Arguments> metodoTestConstructorProducto() {
        
        Producto a = new Producto("a",-2);
        Producto b = new Producto("b",-2);
        Producto c = new Producto("c",-2);
         
        return Stream.of(arguments(a,b,c,true));
        
    } 
 
    
    
    
    
    
    
    

}
