package org.iesalvarofalomir.carrito;

import java.util.*;

/**
 * Implementa un carrito de la compra con productos
 *
 * @author xubaka
 * @version 1.0
 * @since 1992
 * 
 */
public class CarritoCompra {

    private ArrayList<Producto> productos;
/**
 * Constructor para CarritoCompra
 */
    public CarritoCompra() {
        productos = new ArrayList<Producto>();
    }

    /**
     * Calcula el precio total sumando todos los productos del carrito
     * @return la suma total de todos los productos en el carrito
     */
    public double getPrecioTotal() {
        double precioTotal = 0.00;
        for (Producto item : productos) {

            precioTotal += item.getPrecio();
        }
        return precioTotal;
    }

    /**
     * Añade el producto al carrito
     * @param item el producto a añadir al carrito
     */
    public void agregaProducto(Producto item) {
        productos.add(item);
    }

    /**
     * Imprime "metodo deprecated"
     * @param item el producto a añadir al carrito
     * @deprecated
     */
    @Deprecated
    public void agregaProductoOld(Producto item) {
        System.out.println("Metodo deprecated");
    }

    /**
     * Borra el producto del carrito
     * @param item producto a borrar
     */
 public void borraProducto(Producto item) throws ProductNotFoundException {
        if (!productos.remove(item)) {
            throw new ProductNotFoundException();
        }
    }

    /**
     * Devuelve la cantidad de productos en el carrito
     * @return cantidad de productos
     */
    public int getCantidadProductos() {
        return productos.size();
    }

    /**
     * Borra todos los productos del carrito.
     */
    public void vaciarCarrito() {
        productos.clear();
    }
}
