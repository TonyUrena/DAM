package org.iesalvarofalomir.carrito;

/**
 * Excepción para el producto no encontrado
 * @author xubaka
 * @version 1.0
 */
public class ProductNotFoundException extends Exception {

    public ProductNotFoundException() {
        super();
    }
    
}
