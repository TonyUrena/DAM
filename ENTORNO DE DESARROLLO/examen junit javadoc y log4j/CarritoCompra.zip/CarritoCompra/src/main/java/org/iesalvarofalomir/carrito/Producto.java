package org.iesalvarofalomir.carrito;

/**
 * Clase Producto con nombre y precio.
 *
 * @author xubaka
 * @version 1.0
 *
 */
public class Producto {

    private String nombreProducto;
    private double precio;

    /**
     * Constructor para producto. Lanza una excepcion si el precio es negativo
     *
     * @param nombreProducto nombre del producto
     * @param precio precio del producto
     */
    public Producto(String nombreProducto, double precio) {

        if (precio < 0.0) {
            throw new IllegalArgumentException("Precio no puede ser negativo.");
        }

        this.nombreProducto = nombreProducto;
        this.precio = precio;
    }

    /**
     * getter para el nombre del producto
     *
     * @return el nombre del producto
     */
    public String getNombreProducto() {
        return nombreProducto;
    }

    /**
     * getter para el precio del producto
     *
     * @return el precio del producto
     */
    public double getPrecio() {
        return precio;
    }

    /**
     * Comprueba si el objeto existe
     *
     * @param obj Producto a comprobar
     * @return el producto existe o no
     */
    @Override
    public boolean equals(Object obj) {

        boolean result = false;
        Producto p = (Producto) obj;

        if (p.getNombreProducto().equals(nombreProducto)) {
            result = true;
        }

        return result;
    }
}
