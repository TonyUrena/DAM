package org;

/**
 *
 * @author pablo
 */
public class ClaseA {
    
}
