package mis_clases.clase2;
class Clase2
{
}