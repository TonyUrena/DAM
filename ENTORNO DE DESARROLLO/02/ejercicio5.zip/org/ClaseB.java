package org;

/**
 *
 * @author pablo
 */
public class ClaseB {
    
}
