package mis_clases;
class Clase3
{
}