package ejer02;


public class Cliente {

    private String idUser, datosBancarios, direccion, telefono;
    Agencia agencia;
    Reservacion reserva;
    
    public Cliente(Reservacion reserva){
        this.reserva = reserva;
    }
    
    public void reservacion(String tipoReserva){
        
    }

}
