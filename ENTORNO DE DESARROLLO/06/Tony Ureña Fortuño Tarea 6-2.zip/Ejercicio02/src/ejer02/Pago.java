package ejer02;


public class Pago {

    boolean prepago;
    
    public void puntoDeVenta(){
        
    }
    public void transferenciaBancaria(){
        
    }
    
    public void efectivo(){
        
    }

}
