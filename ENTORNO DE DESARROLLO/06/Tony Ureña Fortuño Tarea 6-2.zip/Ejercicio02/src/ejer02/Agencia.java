package ejer02;

import java.util.ArrayList;


public class Agencia {

    public String Nombre, telefono;
    public int numeroCuentas;
    
    ArrayList <Cliente>clientes = new ArrayList();
    
    public void alquilerAutos(){
        
    }

}
