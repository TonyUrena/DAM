package ejercicio01;

import java.util.ArrayList;

public class RedSocial {
    
    String nombre;
    
    ArrayList <Usuario>usuarios;
    
    public void altaDeUsuario(Usuario usuario){
        
    }

    public RedSocial(String nombre, ArrayList<Usuario> usuarios) {
        this.nombre = nombre;
        this.usuarios = usuarios;
    }
    
    
}
