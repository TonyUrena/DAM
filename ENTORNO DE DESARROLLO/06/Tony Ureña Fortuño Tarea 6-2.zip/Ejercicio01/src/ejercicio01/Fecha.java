package ejercicio01;

public class Fecha {
    
    int dia, mes, anio;
    
    public String devolverComoString(){
        String fecha = "";
        return fecha;
    }

    public Fecha(int dia, int mes, int anio) {
        this.dia = dia;
        this.mes = mes;
        this.anio = anio;
    }
    
}
