package ejercicio01;

public class Ejercicio01 {

    public static void main(String[] args) {
        
        
        
    }
    
}
