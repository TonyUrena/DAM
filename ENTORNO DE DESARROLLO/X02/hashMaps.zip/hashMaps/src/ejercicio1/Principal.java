package ejercicio1;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

/**
 *
 * @author pablo
 */
public class Principal {

	public static void main(String[] args) {

		Map<String, Float> mapProductos = Helper.getDatosEjemplo();

		Scanner sc = new Scanner(System.in);
		int opcionElegida = 0;		

		while (opcionElegida != 6) {
			System.out.println("\n--------------------------------");
			System.out.println("Bienvenido a la aplicacion:");
			System.out.println("1.- Introducir producto");
			System.out.println("2.- Modificar precio");
			System.out.println("3.- Mostrar todos los productos");
			System.out.println("4.- Mostrar todos los productos ordenados por nombre de producto");
			System.out.println("5.- Eliminar producto");
			System.out.println("6.- Salir");

			System.out.print("Ingrese opcion (1-6): ");
			opcionElegida = sc.nextInt();

			switch (opcionElegida) {
				
			case 1:
				
				System.out.println("Cuantos Productos va a introducir manualmente?");
				int numeroArticulos = sc.nextInt();
				for (int i = 0; i < numeroArticulos; i++) {
					System.out.println("Introduce el nombre del producto " + (i + 1) + ":");
					String nombreProducto = sc.next();
					System.out.println("Introduce el precio del producto:" + (i + 1) + ":");
					float precio = sc.nextFloat();
					/******************************************************************/
					/*
					 * Implementa la funcion guardarProducto y llamala del siguiente modo...
					 * guardarProducto(nombreProducto, precio, mapProductos); 
					 * Mas abajo en el codigo tienes la definicion de la funcion
					 *****************************************************************/

				}
				break;
			case 2:
				System.out.println("Introduce el nombre del producto del que quieres cambiar el precio:");
				String nombreProducto = sc.next();
				/******************************************************************/
				/*
				 * Define e Implementa la funcion modificarPrecio y llamala del siguiente modo... 
				 * modificaPrecio(nombreProducto, mapProductos); 
				 * Mas abajo en el codigo tienes la definicion de la funcion
				 *****************************************************************/

				break;
			case 3:
				/******************************************************************/
				/*
				 * Define e Implementa la funcion mostrarProductos y llamala del siguiente modo... 
				 * mostrarProductos(mapProductos); 
				 * En caso que no hayan productos en el hashMap devuelve por consola el texto
				 * "No hay articulos guardados" 
				 * Mas abajo en el codigo tienes la definicion de la funcion
				 *****************************************************************/
				break;
			case 4:
				/******************************************************************/
				/*
				 * Define e Implementa la funcion mostrarProductosOrdenadosPorNombre y llamala del siguiente modo... 
				 * mostrarProductosOrdenadosPorNombre(mapProductos); 
				 * En caso que no hayan productos en el hashMap devuelve por consola el texto
				 * "No hay articulos ordenados guardados" 
				 * Mas abajo en el codigo tienes la definicion de la funcion
				 *****************************************************************/
				break;
			case 5:
				System.out.println("Introduce el nombre del producto que quieres eliminar:");
				nombreProducto = sc.next();
				/******************************************************************/
				/*
				 * Define e Implementa la funcion eliminaProducto(ten en cuenta los tipos de los
				 * parametros) y llamala del siguiente modo... 
				 * eliminaProducto(codigo, mapProductos); 
				 * Mas abajo en el codigo tienes la definicion de la funcion 
				 *****************************************************************/

				break;
			case 6:
				System.out.println("\nGracias por usar esta aplicacion.");
				break; // Si la opcion es 6 no se hace nada y se sale del switch
			default:
				System.out.println("Tienes que introducir una opción valida.");
			}

		}
	}

	public static void guardarProducto(String nombreProducto, float precio, HashMap<String, Float> mapProductos) {
		/****************************************************************************/
		/*
		 * Guarda el par (nombreProducto, precio) en el HashMap mapProductos 
		 * Comprueba si el nombre existe 
		 * --Si no existe añade el par (nombreProducto, precio)
		 * --Si existe devuelve por consola el texto "No se puede introducir el producto. El código de articulo esta repetido."
		 ****************************************************************************/
	}

	public static void modificaPrecio(String nombreProducto, HashMap<String, Float> mapProductos) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduce el precio del producto "+"\"" + nombreProducto +"\": ");
		float precio = sc.nextFloat();

		/****************************************************************************/
		/*
		 * Modifica el precio del producto en el HashMap mapProductos 
		 * Comprueba si el nombre existe 
		 * --Si existe modifica el precio y devuelve por consola el texto "Precio modificado"
		 * --Si no existe devuelve por consola el texto "No hay ningun producto con ese nombre."
		 ****************************************************************************/
				
	}

	public static void mostrarProductos(HashMap<String, Float> mapProductos) {
		/****************************************************************************/
		/*
		 * Muestra por consola todo el contenido del HashMap mapProductos /
		 ****************************************************************************/
	}
	
	public static void mostrarProductosOrdenadosPorNombre(HashMap<String, Float> mapProductos) {
		/****************************************************************************/
		/*
		 * Muestra por consola el contenido del HashMap mapProductos en orden alfabetico.
		 * El formato en que se tienen que mostrar los pares (nombre, valor) es el siguiente:
		 * [nombreProducto::precio], ejemplo ["jamon"::7.55]
		 ****************************************************************************/
	}

	public static void eliminaProducto(String nombreProducto, HashMap<String, Float> mapProductos) {
		/****************************************************************************/
		/*
		 * Elimina el producto del HashMap mapProductos 
		 * Comprueba si el nombre existe 
		 * --Si existe elimina el producto y devuelve por consola el texto "Producto eliminado" 
		 * --Si no existe devuelve por consola el texto "No hay ningun producto con ese código." /
		 ****************************************************************************/
	}

}
