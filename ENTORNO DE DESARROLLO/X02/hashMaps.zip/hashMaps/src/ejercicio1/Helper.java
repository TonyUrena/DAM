package ejercicio1;

import java.util.Map;

public class Helper {

    public static Map<String, Float> getDatosEjemplo() {

        return Map.of("leche", 1.25f,
                "huevos", 2.15f,
                "entrecotte de ternera", 12.25f,
                "manzana", 0.92f,
                "cafe molido", 2.78f,
                "salchicas", 3.35f
        );
    }

}
