package ejercicio2;

public class DataKey {

    private String provincia;
    private String abvrProvincia;

}
