package ejercicio2;

import java.util.Comparator;
import java.util.HashMap;
import java.util.List;

/**
 *
 * @author pablo
 */
public class Helper {

    public static void printListadoEstaciones(List<EstacionMeteo> estacionesMeteorologicas) {
        System.out.printf("%-12s%-34s%-23s%-12s%-12s%n", "Indicativo", "Nombre", "Provincia", "Altitud(m)", "Longitud");
        estacionesMeteorologicas.forEach((item) -> System.out.printf("%-12s%-34s%-23s%-12s%-12s%n", item.getIndicativo(), item.getNombre(), item.getProvincia(), item.getAltitud(), item.getLongitud()));
    }

    /**
     * Metodo que recibe una lista de estaciones meteorologicas y construye un
     * hashMap tomando como: -- Clave: un objeto DataKey que contiene el nombre
     * de la provincia junto con la abreviatura del nombre de la provincia (las
     * 4 primeras letras) -- Valor: un arrayList que corresponde con la lista de
     * estaciones meteorologicas de cada provincia
     *
     * @author pablo
     * @param listaEstaciones
     * @return hashmap con toda la información agregada
     */
    public static HashMap<DataKey, List<EstacionMeteo>> creaEstructuraHashMap(List<EstacionMeteo> listaEstaciones) {

        return null;
    }

    /**
     * Metodo que devuelve la lista de estaciones meteorologicas de la provincia
     * pasada por parametro
     *
     *
     * @author pablo
     * @param provincia provincia de la que se quiere extraer la información
     * @param hashMap estructura de datos con la información
     * @return devuelve null si no hay ninguna provincia con estaciones o sino la lista de estaciones.
     */
    public static List<EstacionMeteo> devuelveListaEstacionesMeteorologicasPorProvincia(String provincia, HashMap<DataKey, List<EstacionMeteo>> hashMap) {
        return null;

    }

    /**
     * Metodo que muestra por consola de forma ordenada alfabeticamente el
     * nombre de cada provincia junto con el numero de estaciones que en ella se
     * encuentran. Ademas debe mostrarse también cual es la estación de cada
     * provincia que se encuentra a mas altura.
     *
     * @author pablo
     * @param hashMap estructura de datos con la información
     */
    public static void devuelveProvinciaAndNumeroDeEstacionesAndMaxAltitudOrdenadasPorProvincia(HashMap<DataKey, List<EstacionMeteo>> hashMap) {

    }

}
